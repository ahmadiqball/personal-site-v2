# Handoff: Astrolabe — Personal Portfolio Site

## Overview
A complete personal website for **Ahmad Iqbal Yahya**, a frontend engineer in Bandung, Indonesia. It is a portfolio + writing site with a distinctive "celestial cartographer's atelier" aesthetic: a near-black ink ground, a single candleflame-gold accent, engraved display type, arch-masked imagery, and animated astronomical instruments (armillary sphere, orbits, clockwork gears). There is a bound **design system** in this bundle (`design-system/`) — treat it as the source of truth for tokens, components, and rules.

Pages: home, work archive, work detail (case study), writing archive, article, CV, about, plus colophon / 404 / contact.

## About the Design Files
The `.html` files in this bundle are **design references created in HTML** — hi-fi prototypes showing intended look, motion, and behavior. They are **not** production code to ship as-is. The task is to **recreate these designs in the target codebase's environment**, using its established patterns and libraries. If no codebase exists yet, the recommended stack is **Nuxt 3 / Vue 3 + TypeScript** (the subject's own primary stack) or Next.js — either fits cleanly. Author real components from the design-system primitives rather than pasting page HTML.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, motion, and interactions are all specified here and in `design-system/`. Recreate pixel-faithfully using the codebase's component patterns. Exact hex, type, easing, and timing values are in the Design Tokens section and in `design-system/tokens/`.

## Screens / Views

### 1. Home (`homepage.html`)
- **Purpose:** landing; identity + hero instrument + a peek at work and writing.
- **Layout:** sticky top nav; hero is a 2-col grid (`~1.06fr / 0.94fr`, collapses to 1-col ≤980px) — left copy column, right the **celestial instrument**; below: a tech ticker, a "selected works" archive (4 rows, links to detail pages), a writing teaser, footer.
- **Hero instrument (signature):** a portrait plate (arch: `border-radius: 150px 150px 10px 10px`) at the nucleus of tilted, slowly-rotating armillary shells + orbiting "electron" bodies (one indigo `--nila`) + a graduated watch tick-ring (generated in JS, 72 ticks) + twinkling stars + 3 clockwork gears. All CSS animation; see "Interactions".
- **Copy:** headline "Builder of / small worlds." (Cinzel uppercase); bio; status pill "open to work · q3 2026"; stack line; link row (selected work / github / linkedin / email).

### 2. Work archive (`Work.html`)
- **Purpose:** full portfolio grid.
- **Layout:** page header (title "The Archive" + a stats block: **12 shipped · 94k+ reached · 5 yrs**, plus a ranked "Most used · projects each" list — TypeScript 12, Vue 6, Nuxt 3, React 3, Next 2, Svelte 2, PWA 2, Go 1, D3 1, Prisma 1); a filter/sort rail (by altitude/year/stack — visual reorder only); a **bento grid** of 12 arch-masked project cards sized by prominence (xl / tall / wide / md / sm). Each card: gradient placeholder + drop-in screenshot, index, year, title, one-line desc, hover-revealed CTA.
- A metrics-first alternate exists at `Work-legible.html` (kept for reference; the shipped direction is `Work.html`).

### 3. Work detail / case study (`work/Courtsee.html`) — TEMPLATE
- **Purpose:** one project write-up. This is the pattern for all 12 detail pages.
- **Layout:** nav → breadcrumb → page head (Station, title, meta: year · role · stack · impact) → **header carousel** (the app gallery) → 4/8 body grid (sticky sidebar + long-form essay) → article nav (prev/next) → footer.
- **Header carousel:** 4 arch-masked 16:10 slides, prev/next round buttons, dot indicators, "n / 4" counter, per-slide caption plate. Auto-advance 5s (disabled under reduced-motion), keyboard ←/→, touch swipe. Slides are horizontal-translate on a flex track.
- **Sidebar:** riveted "dossier" plate (year/role/stack/live/repo/status); **Impact** metric grid (14k players · 54 clubs · 3 cities · <30s); **Key features** list.
- **Essay:** numbered `<h2>` sections, Hanken body, gold `<em>`, inline `<code>`.

### 4. Writing archive (`Writing.html`)
- **Purpose:** tech-only notes index (frontend / backend / algorithms / method / opinion).
- **Layout:** header (lede + stats: 12 notes · 5 topics · since 2024); topic filter chips; a **featured post** card (arch-masked cover, "★ start here") linking to the article; then year-banded lists (2026 / 2025 / 2024) of rows with dropcap, title, subtitle, a decorative waveform SVG, and a topic badge + read-time. Asterism dividers between years.

### 5. Article (`writing/rsc-mental-model.html`) — TEMPLATE
- **Purpose:** one long-form tech note. Pattern for all articles.
- **Layout:** nav → breadcrumb → article head (topic·lang·read-time·date eyebrow, Cinzel title, Cardo italic deck, byline) → **arch-masked cover** (16:8, "Fig. I" caption) → centered 680px reading column → end mark (⌬) → article nav → footer.
- **Body components:** first-paragraph drop-cap; numbered `<h2>`; **code blocks** (`.code`, dark panel, gold left-border, mono, token classes `.c` comment / `.k` keyword `#8E86E8` / `.s` string `#9BBF8A` / `.f` function gold); `.pull` quote; `.note` callout; bulleted lists with ▲ markers.

### 6. CV (`CV.html`)
- **Purpose:** résumé; print-ready.
- **Layout:** header (title + deck + meta strip with download/print) → 4/8 grid: sticky TOC (scroll-spy) + content. Content order: **Summary first** (lede + a 4-cell facts grid: Focus/Currently/Shipped/Open to) → Experience → Education → Tech stack (pill groups) → Selected works (**arch-topped project cards**, 2-col) → Speaking & writing → The long version (personal coda + armillary wax seal). Has a dedicated `@media print` stylesheet.

### 7. About (`About.html`)
- **Purpose:** the person.
- **Layout:** hero (copy + the same celestial instrument) → journey timeline → "Currently" (3 plates) → **How I work** (4 principles grid) → contact CTA.

### 8. Support: `colophon.html`, `404.html`, `send-letter.html` (contact), `index.html` (dev artifact — do not ship).

## Interactions & Behavior
- **House easing:** `cubic-bezier(0.2, 0.8, 0.2, 1)` everywhere.
- **Entrances:** fade + rise (`opacity 0→1`, `translateY(12px→0)`), staggered ~130ms; durations 600–1200ms.
- **Ambient (infinite):** armillary shells `spin` 30–220s; orbit tracks 6–22s (electrons faster than shells); `twinkle` 3.6s on stars; `breathe` 3s on the status dot; gears 15/20s cw/ccw; brand monogram rings orbit 60/90/120s.
- **Hover:** links stone→vellum (300ms); cards lift `translateY(-3px)` + border/frame → gold (500ms); nav arrows brighten.
- **Carousel:** translateX flex track (600ms ease); auto 5s; ←/→ keys; touch swipe (>40px); dots + counter sync.
- **CV TOC:** IntersectionObserver scroll-spy highlights the active section.
- **Reduced motion:** every page has `@media (prefers-reduced-motion: reduce)` killing animation; carousel auto-advance is skipped. Preserve this.
- **Filters/sort (Work):** pure client-side DOM reorder, no fetch.

## State Management
Minimal — this is a content site. Per-page local state only:
- Carousel: current index, autoplay timer.
- CV: active TOC section (from observer).
- Work: active sort key + filter.
No global store or data fetching in the prototypes. In a real build, page content (projects, posts) should come from the CMS/content layer of the chosen framework (e.g. Nuxt Content / MDX); the 12 projects and 12 posts are currently hard-coded in markup.

## Design Tokens
Full set in `design-system/tokens/`. Summary:
- **Inks:** `--ink-night #08070C` (page), `--ink-deep #14121A` (card), `--ink-soft #2A2530` (raised).
- **Stone ramp:** `--stone-600 #6B6760`, `--stone-400 #8B857A`, `--stone-200 #B8B2A6`, `--vellum #EDEAE3` (primary text).
- **Accents:** `--candleflame #C9A961` (THE accent — use sparingly), `--nila #5B4FE5` (rare indigo counter), `--ember #8A3A24` (rare warning). Code tokens: keyword `#8E86E8`, string `#9BBF8A`.
- **Hairlines:** vellum at 0.08 / 0.10 / 0.12 alpha; gold hairline `rgba(201,169,97,0.4)`; gold wash `rgba(201,169,97,0.06)`.
- **Type:** Cinzel (display, UPPERCASE, +0.02em) · Hanken Grotesk (UI + body) · Cardo (editorial serif, italic) · JetBrains Mono (labels/meta, leading "— ") · Caveat (marginalia, **max 1/screen**) · MedievalSharp (Station glyphs only). Scale in `tokens/typography.css`.
- **Numerals:** Arabic for all real data (years, counts, dates). Roman ONLY as ornament (Station chapter numbers). No emoji.
- **Radius:** mostly square (≤2px); the roundness lives in the arches (percentage border-radius or clip-path), not the boxes.
- **Shadow:** minimal; floating plates get `0 24px 60px rgba(8,7,12,.6)`.
- **Motion:** easing + keyframes in `tokens/motion.css`.

## Assets
In `design-system/assets/` — single-colour gold line SVGs (no icon library, no emoji):
`monogram.svg` (armillary A·I·Y brand mark), `compass-rose.svg`, `arch-frame.svg`, `gear.svg`, `ridge-divider.svg`, `khatim-tile.svg` (50px fixed-background tessellation @ ~5% opacity), plus `portrait-plate.png` (hero self-portrait). All product screenshots in the prototypes are **placeholders** — arch/striped fallbacks that auto-hide (`onerror`) when a real image is dropped at the referenced path (`work/*.png`, `writing/rsc-cover.png`). The client supplies real screenshots.

## Files (in this bundle)
- `homepage.html`, `Work.html`, `Work-legible.html`, `Writing.html`, `CV.html`, `About.html`, `colophon.html`, `404.html`, `send-letter.html`
- `work/Courtsee.html` (detail template)
- `writing/rsc-mental-model.html` (article template)
- `design-system/` — `readme.md` (full brand + rules), `styles.css` + `tokens/`, `assets/`, `guidelines/` (specimen cards), `components/` (React primitives: Button, Tag, StatCell, RivetedPlate, ArchCard, SectionEyebrow — each with `.jsx` + `.d.ts` + `.prompt.md`).

Start from `design-system/readme.md` — it is the definitive spec.
