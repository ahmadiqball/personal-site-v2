# Assets

Ornaments are single-colour line SVGs in **candleflame gold (#C9A961)** — thin strokes (0.4–1px), drawn on the dark ink ground.

| file | use |
|---|---|
| `monogram.svg` | armillary A·I·Y brand mark (nav) |
| `compass-rose.svg` | wayfinding / back-arrow |
| `arch-frame.svg` | gold outline for arch-masked image plates |
| `gear.svg` | animated clockwork corner ornament |
| `ridge-divider.svg` | mountain-ridge section divider |
| `khatim-tile.svg` | 50×50 repeating background tessellation (opacity ~0.05) |
| `portrait-plate.png` | hero self-portrait (the nucleus of the celestial instrument) |

Never recolour ornaments per-instance; gold is the single accent. The khatim tile tiles as a fixed background at 5% opacity.
