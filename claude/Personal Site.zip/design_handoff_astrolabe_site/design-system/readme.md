# Astrolabe — Design System

The design language of **Ahmad Iqbal Yahya's personal site** (a frontend-engineer portfolio). A "celestial cartographer's atelier": a near-black ink ground, a single candleflame-gold accent, engraved display type, and animated astronomical instruments (armillary spheres, orbits, clockwork gears) as the signature ornament.

**Source:** the site itself, in this project's root — `homepage.html`, `Work.html`, `Writing.html`, `About.html`, `CV.html`, `colophon.html`, `404.html`, `send-letter.html`. Tokens and components below were extracted verbatim from those files. No external Figma or repo.

---

## Content fundamentals
- **Voice:** first person, quiet, exact. "I build interfaces the way some people summit mountains." Confident without boasting; the proudest work is described as *small*.
- **Casing:** display headings are UPPERCASE Cinzel. Mono labels are lowercase or UPPERCASE with a leading `— ` (e.g. `— SELECTED WORK`). Body is sentence case.
- **You vs I:** almost always **I**. The reader is addressed rarely and gently.
- **Numbers:** Arabic for all real data (years `2024`, counts `12`, dates `APR 2026`). Roman numerals survive ONLY as ornament — Station chapter numbers (`Station II`), never for data.
- **Marginalia:** occasional handwritten Caveat asides (`— the summit log`). **Max one per screen.**
- **Emoji:** none. The only glyphs used as ornament are `⌬` (Station marker) and `▲` (altitude/rank), plus `→ ↗` arrows in links.
- **Vibe:** patient, hand-made, cartographic. Field-notes and workshop, not startup dashboard.

## Visual foundations
- **Palette:** ink ground (`#08070C`), card (`#14121A`), text ramp stone-600→vellum, and a **single accent — candleflame gold `#C9A961`**, used sparingly. `nila` indigo `#5B4FE5` is a rare cool counter (a second orbit); `ember` rust is a rare warning. Never introduce new hues; if needed, derive in oklch from these.
- **Type:** Cinzel (display, uppercase, +0.02em) · Hanken Grotesk (UI + body) · Cardo (editorial serif, often italic) · JetBrains Mono (labels/meta) · Caveat (marginalia) · MedievalSharp (Station glyphs only).
- **Backgrounds:** fixed 50px *khatim* line-tessellation at ~5% opacity over everything; page-local topographic contour SVGs at ~6%; occasional radial gold wash at the top.
- **Signature motif — the arch:** images are masked into a Gothic/mihrab arch (`clip-path` with a rounded apex) and outlined with a 0.4–1px gold frame. Used for the hero portrait, all work/writing cards, and galleries.
- **Signature ornament — the celestial instrument:** a portrait at the nucleus of tilted, slowly-rotating armillary shells, with orbiting "electron" bodies (one indigo), a graduated watch tick-ring, twinkling stars, and clockwork gears. Lives on the homepage & About heroes.
- **Animation:** house easing `cubic-bezier(0.2,0.8,0.2,1)`. Entrances fade + rise (`opacity` + `translateY(12px)`), staggered ~130ms. Ambient motion is slow orbit/spin (18–220s), twinkle, and a breathing status dot. All disabled under `prefers-reduced-motion`.
- **Hover:** links brighten stone→vellum (300ms); cards lift `translateY(-3px)` and their border/frame goes gold (500ms). Press: none pronounced.
- **Borders & cards:** hairlines are translucent vellum (`0.08–0.12` alpha); the warm "riveted plate" uses a solid gold border + faint gold wash + four corner rivets. Corners are mostly square (2px at most) — the roundness lives in the arches, not the boxes.
- **Shadows:** minimal; only floating elements (portrait plate) get a deep soft `0 24px 60px rgba(8,7,12,.6)`. No inner shadows except rivet insets.
- **Layout:** generous hairline-divided sections; asymmetric grids (5/7, 4/8, 1.5/1); bento grids sized by prominence. Transparency + blur only on floating labels/nav (`backdrop-filter: blur(8px)` over `rgba(8,7,12,.85)`).
- **Imagery vibe:** cool, painterly, twilight — twin moons, floating islands, engraved plates. Every image gets an arch mask; raw rectangles are avoided.

## Iconography
No icon library. Iconography is **hand-drawn single-colour gold line SVGs** (armillary monogram, compass rose, gears, ice-axe, carabiner, mountain ridge) — see `assets/`. Unicode ornaments `⌬ ▲ →  ↗ ·` stand in for small glyphs. No emoji, no icon font. When you need a new glyph, draw it in the same 0.4–1px gold line style, or reuse an asset — do not import a foreign icon set.

## Index / manifest
- `styles.css` — root entry; `@import`s the four token files. **Consumers link this only.**
- `tokens/` — `fonts.css` (Google Fonts import), `colors.css`, `typography.css`, `motion.css`.
- `assets/` — ornament SVGs + `portrait-plate.png` (+ its own README).
- `guidelines/` — 13 foundation specimen cards (Colors, Type, Motion, Brand).
- `components/` — React primitives, grouped:
  - `forms/Button` — mono link-action with arrow (primary gold / ghost).
  - `core/Tag` — stack pill; `core/StatCell` — metric cell.
  - `feedback/RivetedPlate` — gold dossier panel with rivets.
  - `media/ArchCard` — the signature arch-masked project card.
  - `navigation/SectionEyebrow` — Station glyph + note + title lockup.
- `SKILL.md` — downloadable-skill entry point.

### Intentional additions
- `ArchCard`, `RivetedPlate`, `CelestialInstrument (documented, ornament)` — these are the site's real recurring structures promoted to components; not generic additions.

## Caveats & ask
- **Fonts are Google-Fonts-linked** (no binaries shipped) — fine for web; if you need offline/self-hosted, say so and I'll vendor the `.woff2` files.
- **The celestial instrument** ships as documented CSS/markup (in the site + `guidelines/brand-ornaments`), not as a React component — it's ~40 animated nodes and is better copied than parameterised. Want it as a `<CelestialInstrument/>` component? I can build it.
- **No logo mark exists** beyond the armillary "A·I·Y" monogram (`assets/monogram.svg`) — that IS the brand mark; I did not invent anything.

**Bold ask:** confirm the **namespace** the compiler assigned (the component cards resolve it dynamically, but I'd like to hard-set it), and tell me whether to (a) vendor self-hosted fonts and (b) build the instrument as a real component. Also: set the file type to **Design System** in the Share menu so your org can use it.
