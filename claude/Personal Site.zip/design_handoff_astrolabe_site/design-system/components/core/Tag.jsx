import React from 'react';
/* Small pill for a tech/stack token. 'role' variant is gold-outlined for the lead label. */
export function Tag({ role = false, children }) {
  return (
    <span style={{
      fontFamily: 'var(--f-mono)', fontSize: 8, letterSpacing: '0.08em', textTransform: 'uppercase',
      borderRadius: 999, padding: '3px 7px',
      color: role ? 'var(--candleflame)' : 'var(--stone-400)',
      border: '0.5px solid ' + (role ? 'rgba(201,169,97,0.45)' : 'rgba(139,133,122,0.35)'),
    }}>{children}</span>
  );
}
