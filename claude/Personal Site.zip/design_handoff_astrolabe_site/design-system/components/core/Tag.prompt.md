Rounded pill for a tech or stack token on cards. Group several with flex + gap.

```jsx
<Tag role>Lead FE</Tag><Tag>Vue</Tag><Tag>Nuxt 3</Tag><Tag>TypeScript</Tag>
```
