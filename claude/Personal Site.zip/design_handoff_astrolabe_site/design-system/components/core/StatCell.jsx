import React from 'react';
/* One metric in a hairline grid: mono key, Cinzel value, mono sub. */
export function StatCell({ label, value, sub, gold = false }) {
  return (
    <div style={{ background: 'var(--ink-night)', padding: '16px 16px 14px' }}>
      <div style={{ fontFamily: 'var(--f-mono)', fontSize: 9, letterSpacing: '0.18em', color: 'var(--stone-600)', marginBottom: 8 }}>— {label}</div>
      <div style={{ fontFamily: 'var(--f-cinzel)', fontSize: 26, fontWeight: 500, color: gold ? 'var(--candleflame)' : 'var(--vellum)' }}>{value}</div>
      {sub && <div style={{ fontFamily: 'var(--f-mono)', fontSize: 9, color: 'var(--stone-400)', marginTop: 5 }}>{sub}</div>}
    </div>
  );
}
