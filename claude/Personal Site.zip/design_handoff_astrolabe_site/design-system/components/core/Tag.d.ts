import * as React from 'react';
/** Stack/tech pill. `role` renders the gold-outlined lead variant. */
export interface TagProps { role?: boolean; children: React.ReactNode; }
export function Tag(props: TagProps): JSX.Element;
