A single metric. Lay 3 in a grid with `gap:1px` on a `--line-10` background to get the hairline-divided stat block.

```jsx
<div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:1,background:'var(--line-10)',border:'0.5px solid var(--line-10)'}}>
  <StatCell label="SHIPPED" value="12" sub="since 2021" gold />
  <StatCell label="PEOPLE REACHED" value="94k+" sub="across all work" />
  <StatCell label="EXPERIENCE" value="5 yrs" sub="2021 — 2026" />
</div>
```
