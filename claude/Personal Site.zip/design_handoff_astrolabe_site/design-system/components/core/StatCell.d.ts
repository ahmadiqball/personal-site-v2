import * as React from 'react';
/** A single metric cell. Place several in a 1px-gap grid over a hairline background for the divider effect. */
export interface StatCellProps { label: string; value: React.ReactNode; sub?: string; gold?: boolean; }
export function StatCell(props: StatCellProps): JSX.Element;
