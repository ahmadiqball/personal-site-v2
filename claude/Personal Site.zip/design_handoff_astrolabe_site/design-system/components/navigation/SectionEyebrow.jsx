import React from 'react';
/* Station glyph + handwritten sub, above an optional Cinzel title. */
export function SectionEyebrow({ station, note, title }) {
  return (
    <div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: title ? 12 : 0 }}>
        {station && <span style={{ fontFamily: 'var(--f-medieval)', fontSize: 14, color: 'var(--candleflame)' }}>⌬ {station}</span>}
        {note && <span style={{ fontFamily: 'var(--f-caveat)', fontSize: 17, color: 'var(--stone-400)' }}>— {note}</span>}
      </div>
      {title && <h2 style={{ fontFamily: 'var(--f-cinzel)', fontSize: 28, fontWeight: 500, letterSpacing: '0.02em', textTransform: 'uppercase', color: 'var(--vellum)', margin: 0 }}>{title}</h2>}
    </div>
  );
}
