Section header lockup: a Medieval Station glyph, a Caveat marginal note, and a Cinzel title. One handwritten note per screen — don't stack them.

```jsx
<SectionEyebrow station="Station II" note="the summit log" title="Selected works" />
```
