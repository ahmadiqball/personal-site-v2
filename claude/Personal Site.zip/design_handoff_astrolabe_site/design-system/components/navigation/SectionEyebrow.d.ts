import * as React from 'react';
/** Station glyph + Caveat note, optionally above a Cinzel section title. Caveat note: max one per screen. */
export interface SectionEyebrowProps { station?: string; note?: string; title?: string; }
export function SectionEyebrow(props: SectionEyebrowProps): JSX.Element;
