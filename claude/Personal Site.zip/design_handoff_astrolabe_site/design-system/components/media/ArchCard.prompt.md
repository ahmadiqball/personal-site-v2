The signature tile: an arch-masked image plate (with gradient fallback), gold frame, index/year corners, title block, and a hover-revealed CTA. Size it via the parent grid cell; it fills width and lifts on hover.

```jsx
<ArchCard href="./work/Courtsee.html" index="I ·" year="2024"
  title="Courtsee" desc="Padel platform · 14k players · 54 clubs"
  gradient="linear-gradient(160deg,#1F3340,#2D5F4A 55%,#3D7A4E)" />
```

Drop a real screenshot via `img`; it auto-hides on error and the gradient shows through.
