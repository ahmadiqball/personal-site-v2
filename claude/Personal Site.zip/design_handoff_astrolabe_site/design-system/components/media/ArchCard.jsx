import React from 'react';
/* The signature work/writing card: a Gothic-arch-masked image plate with a gold
   frame, a colour-gradient fallback, index/year corners and a title block. */
export function ArchCard({ href = '#', img, gradient = 'linear-gradient(160deg,#1F3340,#2D5F4A 55%,#3D7A4E)', index, year, title, desc, cta = 'enter →' }) {
  const arch = 'path("M 0 100% L 0 22% Q 0 0 50% 0 Q 100% 0 100% 22% L 100% 100% Z")';
  const [hover, setHover] = React.useState(false);
  return (
    <a href={href} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
       style={{ position: 'relative', display: 'block', textDecoration: 'none', color: 'inherit', background: 'var(--ink-deep)', overflow: 'hidden', minHeight: 300,
                transform: hover ? 'translateY(-3px)' : 'none', transition: 'transform var(--d-med) var(--ease)' }}>
      <div style={{ position: 'absolute', inset: 0, clipPath: arch, WebkitClipPath: arch, overflow: 'hidden', background: gradient }}>
        {img && <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} onError={(e) => { e.currentTarget.style.display = 'none'; }} />}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,transparent 45%,rgba(8,7,12,0.92) 100%)' }} />
      </div>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        <path d="M 0 100 L 0 22 Q 0 0 50 0 Q 100 0 100 22 L 100 100" fill="none" stroke="var(--candleflame)" strokeWidth="0.4" strokeOpacity={hover ? 1 : 0.6} vectorEffect="non-scaling-stroke" />
      </svg>
      <div style={{ position: 'absolute', top: 14, left: 16, fontFamily: 'var(--f-mono)', fontSize: 9, color: 'var(--candleflame)', letterSpacing: '0.22em' }}>{index}</div>
      <div style={{ position: 'absolute', top: 14, right: 16, fontFamily: 'var(--f-mono)', fontSize: 9, color: 'var(--vellum)', letterSpacing: '0.12em' }}>{year}</div>
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '16px 18px 18px' }}>
        <div style={{ fontFamily: 'var(--f-cinzel)', fontWeight: 500, fontSize: 26, letterSpacing: '0.04em', textTransform: 'uppercase', color: 'var(--vellum)', lineHeight: 1 }}>{title}</div>
        {desc && <div style={{ fontFamily: 'var(--f-sans)', fontSize: 13, color: 'var(--stone-200)', lineHeight: 1.4, marginTop: 6 }}>{desc}</div>}
        <div style={{ fontFamily: 'var(--f-mono)', fontSize: 9, color: 'var(--candleflame)', letterSpacing: '0.2em', marginTop: 10, opacity: hover ? 1 : 0, transition: 'opacity var(--d-med) var(--ease)' }}>{cta}</div>
      </div>
    </a>
  );
}
