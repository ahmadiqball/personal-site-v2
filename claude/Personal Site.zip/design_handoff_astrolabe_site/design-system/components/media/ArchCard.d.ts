import * as React from 'react';
/**
 * Gothic-arch-masked image card — the signature work/writing tile.
 * @startingPoint section="Media" subtitle="Arch-masked project card" viewport="360x320"
 */
export interface ArchCardProps {
  href?: string; img?: string; gradient?: string;
  index?: string; year?: string; title: string; desc?: string; cta?: string;
}
export function ArchCard(props: ArchCardProps): JSX.Element;
