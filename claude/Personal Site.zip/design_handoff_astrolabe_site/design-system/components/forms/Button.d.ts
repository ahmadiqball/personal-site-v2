import * as React from 'react';
/**
 * Link-style action (mono label + arrow). Gold 'primary' or muted 'ghost'.
 * @startingPoint section="Forms" subtitle="Mono link-action with arrow" viewport="300x80"
 */
export interface ButtonProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: 'primary' | 'ghost';
  href?: string;
  arrow?: boolean;
  children: React.ReactNode;
}
export function Button(props: ButtonProps): JSX.Element;
