Link-style action — a mono, letter-spaced label with an optional trailing arrow; use for CTAs and nav-like actions (there are no filled buttons in this system).

```jsx
<Button href="Work.html">selected work</Button>
<Button variant="ghost" arrow={false}>colophon ↗</Button>
```

- `primary` = candleflame gold; `ghost` = stone-600. Both brighten to vellum on hover.
