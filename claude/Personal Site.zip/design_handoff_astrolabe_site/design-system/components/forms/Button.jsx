import React from 'react';
/* Link-style action used across the site: a mono, letter-spaced label with an
   optional arrow. 'primary' is gold; 'ghost' is muted stone that brightens on hover. */
export function Button({ variant = 'primary', href = '#', arrow = true, children, ...rest }) {
  const base = {
    fontFamily: 'var(--f-mono)', fontSize: 11, letterSpacing: '0.1em',
    textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 6,
    transition: 'color var(--d-fast) var(--ease)',
    color: variant === 'primary' ? 'var(--candleflame)' : 'var(--stone-600)',
  };
  const [hover, setHover] = React.useState(false);
  return (
    <a href={href} style={{ ...base, color: hover ? 'var(--vellum)' : base.color }}
       onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} {...rest}>
      {children}{arrow && <span aria-hidden="true">→</span>}
    </a>
  );
}
