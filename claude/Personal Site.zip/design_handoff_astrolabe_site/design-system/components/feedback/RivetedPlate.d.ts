import * as React from 'react';
/** Gold-bordered panel with corner rivets — used for dossiers, legends, callouts. */
export interface RivetedPlateProps { eyebrow?: string; children: React.ReactNode; }
export function RivetedPlate(props: RivetedPlateProps): JSX.Element;
