import React from 'react';
/* Gold-outlined panel with four corner rivets — the 'dossier' surface. */
export function RivetedPlate({ eyebrow, children }) {
  const rivet = (pos) => (<span style={{ position: 'absolute', width: 5, height: 5, background: 'var(--candleflame)', borderRadius: '50%', boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.4)', ...pos }} />);
  return (
    <div style={{ position: 'relative', padding: '22px 24px', border: '1px solid var(--candleflame)', background: 'var(--gold-wash)' }}>
      {rivet({ top: 5, left: 5 })}{rivet({ top: 5, right: 5 })}{rivet({ bottom: 5, left: 5 })}{rivet({ bottom: 5, right: 5 })}
      {eyebrow && <div style={{ fontFamily: 'var(--f-mono)', fontSize: 9, color: 'var(--candleflame)', letterSpacing: '0.22em', marginBottom: 14 }}>— {eyebrow}</div>}
      {children}
    </div>
  );
}
