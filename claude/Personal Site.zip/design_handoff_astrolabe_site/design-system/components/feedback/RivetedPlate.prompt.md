The warm 'dossier' panel: gold border, faint gold wash, four corner rivets. Use for project metadata, legends, and highlighted asides — the one warm element on an otherwise cool page.

```jsx
<RivetedPlate eyebrow="DOSSIER">
  <div style={{fontFamily:'var(--f-mono)',fontSize:11,color:'var(--vellum)'}}>Vue · Nuxt · TS</div>
</RivetedPlate>
```
