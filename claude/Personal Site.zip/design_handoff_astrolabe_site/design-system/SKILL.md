---
name: astrolabe-design
description: Use this skill to generate well-branded interfaces and assets for Ahmad Iqbal Yahya's "Astrolabe" personal-site design system — a celestial-cartographer aesthetic (ink ground, single candleflame-gold accent, Cinzel display type, arch-masked imagery, animated armillary instruments). For production or throwaway prototypes/mocks.
user-invocable: true
---

Read `readme.md` first, then explore the token files, `assets/`, `guidelines/` specimen cards, and `components/`.

Core rules to internalise:
- One accent only — candleflame gold `#C9A961` on ink `#08070C`. Cinzel for uppercase display, Hanken Grotesk for body/UI, JetBrains Mono for labels.
- Mask every image into the Gothic arch with a gold frame. Size cards by prominence (bento).
- Arabic numerals for data; Roman only for Station chapter numbers. Max one handwritten Caveat note per screen. No emoji.
- House easing `cubic-bezier(0.2,0.8,0.2,1)`; entrances fade + rise; ambient motion is slow orbit/twinkle; honour `prefers-reduced-motion`.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets out and produce static HTML linking `styles.css` for the user to view. If working on production code, copy assets and apply the rules here. If invoked with no guidance, ask what they want to build, ask a few questions, and act as an expert designer outputting HTML artifacts or production code.
